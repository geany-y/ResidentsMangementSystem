var ExcelSql = (function(){
	var shell = new ActiveXObject('WScript.Shell');
	//var http = new ActiveXObject("Msxml1.XMLHTTP");
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var ado = new ActiveXObject("ADODB.Connection");
	var result_tsv = '';
	var filepath = "f:\\Share\\storage\\Private\\SunGrace\\Residents\\db\\DB.xls";


	function _escapeTSV(data){
		if(typeof data == 'string'){
			data = '"' + data.replace(/"/g,'""') + '"';
		}
		return data;
	}

	function _closeADO(){
		try{
			ado.Close();
		}catch( e ){

		}
		//ado = null;
		// 成功メッセージ
	}

	function _loadDatabase( filepath, readonly, hdr ){
		_closeADO();
		var connect = [];
		if( filepath.match(/\.xls$/i) ){
			connect.push('Driver={Microsoft Excel Driver (*.xls)}; DBQ=' + filepath + ';HDR=' + (hdr ? 'Yes' : 'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.Jet.OLEDB.4.0;Excel 8.0;DATABASE=' + filepath + ';HDR=' + (hdr ? 'Yes' : 'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0;Data Source=' + filepath + ';Extended Properties="Excel 8.0;HDR=' + (hdr ? 'Yes' : 'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=MSDASQL.1;Extended Properties="DBQ=' + filepath + ';DefaultDir=C:\;Driver={Microsoft Excel Driver (*.xls)};DriverId=790;"');
		}else if( filepath.match(/(\.xlsx|\.xlsm|\.xlsb)$/i) ){
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 12.0;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 12.0 Xml;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 12.0 Macro;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 12.0;IMEX=1;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 14.0;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Provider=Microsoft.ACE.OLEDB.12.0; Data Source=' + filepath + '; Extended Properties="Excel 14.0;IMEX=1;HDR=' + (hdr ? 'Yes' :'No') + ';ReadOnly=' + (readonly ? 1 : 0) + ';"');
			connect.push('Driver={Microsoft Excel Driver (*.xls, *.xlsx, *.xlsm, *.xlsb)}; DBQ=' + filepath + ';ReadOnly=' + (readonly ? 1 : 0));
		}else if( filepath.match(/\.csv$/i) ){
			connect.push('Driver={Microsoft Text Driver (*.txt; *.csv)}; DBQ=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';MaxScanRows=8;');
			connect.push('Driver={Microsoft Text Driver (*.txt; *.csv)}; DBQ=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';');
			connect.push('Provider=Microsoft.Jet.OLEDB.4.0;TEXT;DATABASE=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';');
		}else if( filepath.match(/(\.txt|\.tsv)$/i) ){
			connect.push('Driver={Microsoft Text Driver (*.txt; *.csv)}; DBQ=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';Format=TabDelimited' + ';MaxScanRows=8;');
			connect.push('Driver={Microsoft Text Driver (*.txt; *.csv)}; DBQ=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';Format=TabDelimited' + ';');
			connect.push('Provider=Microsoft.Jet.OLEDB.4.0;TEXT;DATABASE=' + fso.GetParentFolderName(filepath) + ';ReadOnly=' + (readonly ? 1 : 0) + ';FirstRowHasNames=' + (hdr ? '1' : '0') + ';Format=TabDelimited' + ';');
		}else if( filepath.match(/\.mdb$/i) ){
			connect.push('Provider=Microsoft Office 12.0 Access Database Engine OLE DB Provider;Data Source="' + filepath + '";');
			connect.push('Provider=Microsoft.Jet.OLEDB.4.0;Data Source="' + filepath + '";');
		}else if( filepath.match(/(\.html|\.html)$/i) ){
			connect.push('Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties="HTML Import;DATABASE=' + filepath + '";');
		}else{
			alert('Unsupported File!');
		}

		for(var i in connect){
			try{
				ado.Open(connect[i]);
				// success message
				break;
			}catch(e){
	//            alert(e.message);
				// error message
			}
		}
	}

	function _executeSQL( sql ){
		try{
			return ado.Execute(sql);
		}catch( e ){
			alert(e.message);
		}
	}

	function _createTableFromRecordSet( rs ){
		var table = document.createElement('table');
		var thead = document.createElement('thead');
		var tbody = document.createElement('tbody');
		var row;
		var cell;
		var buf_tsv = [];
		var buf_tsv_row = [];
		var count = 0;

		if( !rs.Eof ){
			var fc = rs.Fields.Count;

			var row = document.createElement('tr');
			for( var i = 0; i < fc; i++ ){
				cell = document.createElement('th');
				cell.innerText = rs.Fields(i).name;
				cell.title = rs.Fields(i).Type;
				row.appendChild(cell);
				buf_tsv_row.push( _escapeTSV(rs.Fields(i).name) );
			}
			thead.appendChild(row);
			buf_tsv.push( buf_tsv_row.join('\t') );
			while( !rs.Eof ){
				var row = document.createElement('tr');
				buf_tsv_row = [];
				for( var i = 0; i < fc; i++ ){
					var v = String(rs.Fields(i).value).replace('null','---');
					cell = document.createElement('td');
					cell.innerText = v;
					row.appendChild(cell);
					buf_tsv_row.push( _escapeTSV(v) );
				}
				tbody.appendChild(row);
				buf_tsv.push( buf_tsv_row.join('\t') );
				count++;
				rs.MoveNext();
			}
			table.appendChild(thead);
			table.appendChild(tbody);
		}
		return {"count":count,"dom_table":table,"tsv":buf_tsv.join('\n')};
	}

	return {
		'openDb' : function(){
			_loadDatabase(filepath, 1, 0);
		},
		'closeDb' : function(){
			_closeADO();
		},
		'execute' : function(sql){
			return _executeSQL(sql);
		},
		'createTableFromRecordSet' : function(rs){
			return _createTableFromRecordSet(rs);
		}
	};
})();
